public class TicTac {
  public static void main(String[] args){
		Tic tic = null;
		Tac tac = null;

		tic = new Tic(1);
		tac = new Tac(1);
		
		tic.start(); //iniciar hilo
		tac.start(); //iniciar hilo






	} //fin main
} //clase usa hilo
